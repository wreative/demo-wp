{% if lightbox_type == "none" %}
#{{uc_id}} .ug-thumb-wrapper.ug-tile{
  	pointer-events: none;
}
{% endif %}

#wrapper{{uc_id}}
{
  min-height:1px;
}