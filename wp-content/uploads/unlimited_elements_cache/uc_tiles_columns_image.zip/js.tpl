jQuery(document).ready(function(){	
function {{uc_id}}_start(){
  
  var objWrapper = jQuery("#{{uc_id}}");
  
  var api = objWrapper.unitegallery({
    gallery_theme:"tiles",
    gallery_width:"{{gallery_width}}",
    
    tiles_type: "{{gallery_type}}",   
    tiles_align:"{{tiles_align}}",
    tiles_col_width:{{tiles_col_width_nounit}},
    tiles_justified_space_between:{{tiles_space_between_cols_nounit}},                                 
    tiles_space_between_cols:{{tiles_space_between_cols_nounit}},
    tiles_space_between_cols_mobile: {{tiles_space_between_cols_mobile_nounit}},
    tile_as_link: {{tile_as_link}},
    tile_link_newpage: {{tile_link_newpage}},
    tiles_min_columns: {{tiles_min_columns_nounit}},
    tile_overlay_opacity: {{tile_overlay_opacity_nounit}},
    tile_overlay_color: "{{tile_overlay_color}}",   
    tile_background_color: "{{tile_background_color}}",                               
    slider_video_autoplay:{{autoplay_video_in_lightbox}},

                                
    {% if tile_enable_border == "true" %}
        tile_enable_border:{{tile_enable_border}},
        tile_border_color:"{{tile_border_color}}",
        tile_border_width:{{tile_border_width_nounit}},
        tile_border_radius:{{tile_border_radius_nounit}}, 
        
    {% endif %}	

    {% if tile_enable_shadow == "true" %}
        tile_enable_shadow:{{tile_enable_shadow}},
        tile_shadow_color:"{{tile_shadow_color}}",
        tile_shadow_h:{{tile_shadow_h_nounit}},					
		tile_shadow_v:{{tile_shadow_v_nounit}},					
		tile_shadow_blur:{{tile_shadow_blur_nounit}},					
		tile_shadow_spread:{{tile_shadow_spread_nounit}},
     {% endif %}                               
    
    {% if tile_enable_image_effect == "true" %}
        tile_enable_image_effect:{{tile_enable_image_effect}},
        tile_image_effect_type: "{{tile_image_effect_type}}",
        tile_image_effect_reverse: {{tile_image_effect_reverse}},
    {% endif %}   
                                  
    tile_enable_textpanel:{{tile_enable_textpanel}},
	tile_textpanel_source:"{{text_panel_source}}",
    tile_textpanel_always_on: {{tile_textpanel_always_on}},
    tile_textpanel_appear_type: "{{tile_textpanel_appear_type}}",
    tile_textpanel_position:"{{tile_textpanel_position}}",
    tile_textpanel_padding_top:{{tile_textpanel_padding_nounit}},		 	
	tile_textpanel_padding_bottom:{{tile_textpanel_padding_nounit}},	 	
	tile_textpanel_padding_right: {{tile_textpanel_padding_nounit}},	 	
	tile_textpanel_padding_left: {{tile_textpanel_padding_nounit}},
    tile_textpanel_bg_color:"{{tile_textpanel_bg_color}}",
    tile_textpanel_bg_opacity:{{tile_textpanel_bg_opacity_nounit}},
    tile_textpanel_title_text_align:"{{tile_textpanel_title_text_align}}",
    tile_textpanel_title_color:"{{tile_textpanel_title_color}}",
                                                                 
    lightbox_type: "{{lightbox_type}}",
    lightbox_hide_arrows_onvideoplay: {{lightbox_hide_arrows_onvideoplay}},
    lightbox_arrows_position: "{{lightbox_arrows_position}}",                                
    lightbox_overlay_color:"{{lightbox_overlay_color}}",
    lightbox_overlay_opacity:{{lightbox_overlay_opacity_nounit}},	
    lightbox_show_numbers: {{lightbox_show_numbers}},
    lightbox_show_textpanel: {{lightbox_show_textpanel}},
    lightbox_slider_control_swipe:{{lightbox_slider_control_swipe}},
    lightbox_slider_control_zoom:{{lightbox_slider_control_zoom}},
    lightbox_textpanel_title_text_align:"{{lightbox_textpanel_title_text_align}}",
                                    
    lightbox_slider_image_border: {{lightbox_slider_image_border}},
    lightbox_slider_image_border_width: {{lightbox_slider_image_border_width_nounit}},
    lightbox_slider_image_border_color: "{{lightbox_slider_image_border_color}}",
    lightbox_slider_image_border_radius: {{lightbox_slider_image_border_radius_nounit}},
    slider_video_muted: {{mute_video}},   
                                    
    tile_enable_icons: {{tile_enable_icons}}                                  
  });
    
	objWrapper.on("uc_ajax_sethtml",function(event, htmlItems, isAppend){
      
      	if(isAppend == true)
        	api.addItems(htmlItems);         
    	else
        	api.changeItems(htmlItems);         
          
    });
  
  
}if(jQuery("#{{uc_id}}").length) {{uc_id}}_start(); else
	jQuery( document ).on( 'elementor/popup/show', () => { if(jQuery("#{{uc_id}}").length) {{uc_id}}_start();});
});