<div id="wrapper{{uc_id}}">
<div id="{{uc_id}}" style="display:none;" class="uc-items-wrapper{{uc_filtering_addclass}}" data-custom-sethtml="true" {{uc_filtering_attributes|raw}}>

{{put_items()}}
  
</div>
</div>