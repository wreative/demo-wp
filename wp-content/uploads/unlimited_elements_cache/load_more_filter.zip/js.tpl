{% if(is_infinite == "true" and uc_inside_editor != "yes") %}
      
if(typeof ucIsElementInViewport != "function"){
  function ucIsElementInViewport(objElement){

    var elementTop = objElement.offset().top;
    var elementBottom = elementTop + objElement.outerHeight();
    
    var viewportTop = jQuery(window).scrollTop();
    var viewportBottom = viewportTop + jQuery(window).height();
	
    return (elementBottom > viewportTop && elementTop < viewportBottom);
  }
}

jQuery(document).ready(function(){
    
  var objLoadmore = jQuery("#{{uc_id}}");
  var objLink = objLoadmore.find(".uc-filter-load-more__link");
  var isInfiniteScroll = "{{is_infinite}}";
  var showAfter = "{{show_button_after}}";
  showAfter = parseInt(showAfter);
  
  if(!objLink || objLink.length == 0)
    return(false);
      
  if(isInfiniteScroll !== "true")
	  return(false);
  
   /**
    * check and trigger
   */
  function checkTrigger(){
	
      var hasButtonVisibleClass = objLoadmore.hasClass("uc-button-visible");
      if(hasButtonVisibleClass == true)
         return(false);
    
	  var parentObj = objLink.parent();
	  if(parentObj.length == 0)
		  objLink = objLoadmore.find(".uc-filter-load-more__link");
	  
	  if(objLink.length == 0)
		  return(true);
	    
	  var isClassExists = objLink.hasClass("uc-link-trigger");
      	  
	  if(isClassExists == true)
		  return(true);
	  
      var isInViewport = ucIsElementInViewport(objLink);
        
	  if(isInViewport == false)
        return(true);
            
	  objLink.addClass("uc-link-trigger");
	  
      objLink.trigger("click");
      	  
  }

  objLoadmore.on("uc_ajax_reloaded",function(){
  		if(showAfter <= 0)
          return(true);
        
       showAfter--;
        
       if(showAfter == 0)
       		objLoadmore.addClass("uc-button-visible");
        
  });
  
    jQuery(window).scroll(function(){
		checkTrigger();
    });
  
	setTimeout(function(){
      
    	checkTrigger();
      
        var objGrid = objLoadmore.data("grid");
  		
      	objGrid.on("uc_ajax_refreshed", checkTrigger);
    },500);
    
});
 
 {% endif %}